def hello_world()
	"""Returns a 'Hello, World!' message"""
	return "Hello, World!"

def print_hello()
	"""Prints 'Hello, World!' message"""
	print(hello_world())
	